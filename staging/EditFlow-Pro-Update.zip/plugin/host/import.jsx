function editflowImport(path) {
    try {
        if (!app.project) return 'ERROR: Open a Premiere project first.';
        var paths = [path];
        var result = app.project.importFiles(paths, true, app.project.rootItem, false);
        if (result === false) return 'ERROR: Premiere rejected the import: ' + path;
        return 'OK';
    } catch (e) { return 'ERROR: ' + e.toString(); }
}

function editflowTrackInfo(cameraIndex, micIndex) {
    try {
        var seq = app.project.activeSequence;
        if (!seq) return 'ERROR: Open a sequence in Premiere first.';
        if (cameraIndex === micIndex) return 'ERROR: Choose two different audio tracks.';
        if (cameraIndex<0 || micIndex<0 || cameraIndex>=seq.audioTracks.numTracks || micIndex>=seq.audioTracks.numTracks) return 'ERROR: Selected audio track does not exist.';
        var ca=seq.audioTracks[cameraIndex], mi=seq.audioTracks[micIndex];
        if (ca.clips.numItems!==1 || mi.clips.numItems!==1) return 'ERROR: Preview safety requires exactly one audio clip on each selected track. No edits were made.';
        var c=ca.clips[0], m=mi.clips[0];
        if (!c.projectItem || !m.projectItem) return 'ERROR: Track has no source media.';
        var cp=c.projectItem.getMediaPath(), mp=m.projectItem.getMediaPath();
        if (!cp || !mp) return 'ERROR: Both clips must point to local source media.';
        return JSON.stringify({sequence:seq.name,cameraTrack:cameraIndex+1,micTrack:micIndex+1,
            cameraPath:cp,micPath:mp,cameraStart:Number(c.start.seconds),micStart:Number(m.start.seconds),
            cameraIn:Number(c.inPoint.seconds),micIn:Number(m.inPoint.seconds),
            cameraNode:String(c.nodeId),micNode:String(m.nodeId),
            cameraDisabled:Boolean(c.disabled),micDisabled:Boolean(m.disabled)});
    } catch(e) { return 'ERROR: '+e.toString(); }
}
function editflowApplySync(cameraIndex,micIndex,cameraNode,micNode,originalCamStart,originalMicStart,shift,muteCamera){
    try {
        var seq=app.project.activeSequence;
        if (!seq) return 'ERROR: No active sequence.';
        if(cameraIndex===micIndex || cameraIndex<0 || micIndex<0 || cameraIndex>=seq.audioTracks.numTracks || micIndex>=seq.audioTracks.numTracks) return 'ERROR: Invalid track selection.';
        var ca=seq.audioTracks[cameraIndex], mi=seq.audioTracks[micIndex];
        if(ca.clips.numItems!==1 || mi.clips.numItems!==1) return 'ERROR: Tracks changed. Analyze again.';
        var c=ca.clips[0],m=mi.clips[0];
        if(String(c.nodeId)!==cameraNode || String(m.nodeId)!==micNode) return 'ERROR: Clips changed. Analyze again.';
        if(Math.abs(Number(c.start.seconds)-originalCamStart)>0.02 || Math.abs(Number(m.start.seconds)-originalMicStart)>0.02) return 'ERROR: Timeline changed. Analyze again.';
        if(!isFinite(shift) || Math.abs(shift)>60) return 'ERROR: Unsafe sync offset.';
        var target=originalCamStart+shift;
        // A mic with a negative start can instead be slipped into its source at timeline zero.
        // Restrict this preview workaround to small negative starts and a single uncut clip.
        if (target < -0.000001) {
            var trim=-target;
            if (trim>0.25 || originalMicStart>0.001 || Math.abs(originalCamStart)>0.001)
                return 'ERROR: Negative offset exceeds safe preview range (0.25s) or clips are not at timeline zero; no changes made.';
            var oldIn=Number(m.inPoint.seconds), oldOut=Number(m.outPoint.seconds);
            var oldStart=Number(m.start.seconds), oldEnd=Number(m.end.seconds);
            if (!isFinite(oldIn)||!isFinite(oldOut)||!isFinite(oldStart)||!isFinite(oldEnd)||oldOut-oldIn<trim+0.02)
                return 'ERROR: Mic has insufficient source range for negative offset; no changes made.';
            var changed=false;
            try {
                // A time-zero clip cannot be moved into negative timeline time.
                // Slipping the SOURCE in-point forward by trim plays what would
                // have appeared at timeline zero after a negative move.
                var newIn=new Time();newIn.seconds=oldIn+trim;
                m.inPoint=newIn;
                changed=true;
                // Trim visible end by the same amount, preventing extension
                // beyond the original source out-point.
                var newEnd=new Time();newEnd.seconds=oldEnd-trim;
                m.end=newEnd;
                var a=Number(m.inPoint.seconds), b=Number(m.start.seconds), e=Number(m.end.seconds);
                if(Math.abs(a-(oldIn+trim))>0.005 || Math.abs(b)>0.005 || Math.abs(e-(oldEnd-trim))>0.005)
                    throw Error('Premiere did not retain expected source in-point/start/end');
                if(muteCamera) c.disabled=true;
                return 'OK: Mic negative sync applied: trimmed '+trim.toFixed(3)+'s from source start; camera clip '+(muteCamera?'disabled':'unchanged')+'. Verify lip sync.';
            } catch(failure) {
                if(changed) {
                    try {var restoreIn=new Time();restoreIn.seconds=oldIn;m.inPoint=restoreIn;}catch(ignored){}
                    try {var restoreEnd=new Time();restoreEnd.seconds=oldEnd;m.end=restoreEnd;}catch(ignored2){}
                }
                return 'ERROR: Negative sync could not be verified. '+failure.toString()+'; check duplicate sequence (rollback attempted).';
            }
        }
        var delta=target-originalMicStart;
        var deltaTime=new Time(); deltaTime.seconds=delta;
        // TrackItem.move takes a delta, not an absolute sequence time.
        var moved=m.move(deltaTime);
        if(moved!==0) return 'ERROR: Premiere did not move the microphone clip: '+moved;
        if(muteCamera) {
            var muted=c.disabled=true;
            // Clip-level disable keeps other clips on A1 untouched.
        }
        return 'OK: Microphone moved by '+delta.toFixed(3)+'s; camera clip '+(muteCamera?'disabled':'unchanged')+'.';
    } catch(e) { return 'ERROR: '+e.toString(); }
}

// Works when A1 is a nested AutoCut sequence; only A2 must have source media.
function editflowMicTrackInfo(micIndex) {
    try {
        var seq=app.project.activeSequence;
        if(!seq)return 'ERROR: Open the AutoCut sequence first.';
        if(micIndex<0 || micIndex>=seq.audioTracks.numTracks)return 'ERROR: Microphone track does not exist.';
        var track=seq.audioTracks[micIndex];
        if(track.clips.numItems!==1)return 'ERROR: Microphone track must have exactly one uncut source clip.';
        var item=track.clips[0];
        if(!item.projectItem)return 'ERROR: Microphone clip has no project item.';
        var path=item.projectItem.getMediaPath();
        if(!path)return 'ERROR: Microphone track is a nested sequence; add the original audio file to A2.';
        return JSON.stringify({sequence:seq.name,micTrack:micIndex+1,micPath:path});
    }catch(e){return 'ERROR: '+e.toString();}
}

// v0.6 safe read-only active-sequence inspection. No timeline mutations.
function editflowTimelineInspect(){
  try {
    if (!app.project || !app.project.activeSequence) return 'ERROR: Open a Premiere sequence first.';
    var q=app.project.activeSequence, tracks={video:[],audio:[]};
    function describe(track,i){
      var clips=[];
      for(var j=0;j<track.clips.numItems;j++){
        var c=track.clips[j], item=c.projectItem, path='';
        if(item){ try{path=item.getMediaPath()||'';}catch(e){} }
        clips.push({name:String(c.name||''),start:Number(c.start.seconds),end:Number(c.end.seconds),source:path,nested:!path});
      }
      return {track:i+1,clipCount:clips.length,clips:clips.slice(0,30),truncated:clips.length>30};
    }
    for(var i=0;i<q.videoTracks.numTracks;i++)tracks.video.push(describe(q.videoTracks[i],i));
    for(var k=0;k<q.audioTracks.numTracks;k++)tracks.audio.push(describe(q.audioTracks[k],k));
    return JSON.stringify({sequence:String(q.name),tracks:tracks});
  } catch(e){return 'ERROR: '+e.toString();}
}

// v0.7: read synced source ranges; never mutate the active sequence.
function editflowTimelineCutSnapshot(videoIndex,micIndex) {
 try {
  var seq=app.project.activeSequence;
  if(!seq)return 'ERROR: Open a sequence first.';
  if(videoIndex<0||videoIndex>=seq.videoTracks.numTracks||micIndex<0||micIndex>=seq.audioTracks.numTracks)return 'ERROR: Invalid tracks.';
  var vTrack=seq.videoTracks[videoIndex],aTrack=seq.audioTracks[micIndex];
  if(vTrack.clips.numItems!==1||aTrack.clips.numItems!==1)return 'ERROR: Use one uncut camera video and one synced microphone clip.';
  var v=vTrack.clips[0],a=aTrack.clips[0];
  if(!v.projectItem||!a.projectItem)return 'ERROR: Source media unavailable.';
  var vp=v.projectItem.getMediaPath(),ap=a.projectItem.getMediaPath();
  if(!vp||!ap)return 'ERROR: Nested sequences are not supported by this safe export. Use original camera and microphone clips.';
  function details(c,path){return {path:path,name:String(c.name||''),start:Number(c.start.seconds),end:Number(c.end.seconds),source_in:Number(c.inPoint.seconds),source_out:Number(c.outPoint.seconds),node:String(c.nodeId)};}
  var duration=Number(seq.end.seconds);
  return JSON.stringify({sequence:String(seq.name),video:details(v,vp),mic:details(a,ap),videoTrack:videoIndex+1,micTrack:micIndex+1,sequenceDuration:duration});
 }catch(e){return 'ERROR: '+e.toString();}
}


// Read-only caption snapshot; separate from AutoCut and valid after reopening Premiere.
function editflowCaptionSnapshot(audioIndex) {
 try {
  var seq=app.project.activeSequence;
  if(!seq)return 'ERROR: Open the sequence you want to caption first.';
  if(audioIndex<0||audioIndex>=seq.audioTracks.numTracks)return 'ERROR: Audio track does not exist.';
  var track=seq.audioTracks[audioIndex], clips=[];
  if(track.clips.numItems===0)return 'ERROR: Selected track is empty.';
  if(track.clips.numItems>3000)return 'ERROR: Too many audio clips (max 3000).';
  for(var i=0;i<track.clips.numItems;i++) {
   var c=track.clips[i],media=c.projectItem,source='';
   if(media)try {source=media.getMediaPath()||'';}catch(ignore){}
   if(!source)source='';
   if(c.disabled)continue;
   clips.push({path:source,start:Number(c.start.seconds),end:Number(c.end.seconds),source_in:Number(c.inPoint.seconds),source_out:Number(c.outPoint.seconds),name:String(c.name||'')});
  }
  if(!clips.length)return 'ERROR: All clips on selected track are disabled.';
  return JSON.stringify({sequence:String(seq.name),audioTrack:audioIndex+1,duration:Number(seq.end.seconds),clips:clips,clipCount:track.clips.numItems});
 }catch(e){return 'ERROR: '+e.toString();}
}
