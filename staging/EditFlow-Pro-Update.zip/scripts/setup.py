"""Windows setup without elevation or PowerShell policy changes."""
import hashlib, json, os, platform, shutil, subprocess, sys, venv
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def call(args):subprocess.run([str(x) for x in args],check=True)
def main():
 if os.name!='nt' or platform.machine().lower() not in ('amd64','x86_64') or sys.version_info[:2]!=(3,11):
  raise SystemExit('Install Python 3.11 x64 from python.org, then run Install.cmd.')
 env=ROOT/'.venv';venv.EnvBuilder(with_pip=True).create(env);python=env/'Scripts/python.exe'
 call([python,'-m','pip','install','--index-url','https://pypi.org/simple','--only-binary=:all:','--require-hashes','-r',ROOT/'requirements-win-py311.lock'])
 call([python,'-m','pip','check'])
 call([python,'-c','from faster_whisper import WhisperModel; import ctranslate2, av, onnxruntime; print("AI dependencies imported successfully")'])
 tools=ROOT/'tools'/'ffmpeg'/'bin'
 os.environ['PATH']=str(tools)+os.pathsep+os.environ['PATH']
 audit={}
 for name in ('ffmpeg','ffprobe'):
  exe=shutil.which(name)
  if not exe:raise SystemExit('Python ready. FFmpeg missing. Follow docs/WINDOWS.md, then run Install.cmd again.')
  output=subprocess.check_output([exe,'-version'],text=True).splitlines()[0]
  audit[name]={'path':exe,'version':output,'sha256':hashlib.sha256(Path(exe).read_bytes()).hexdigest()}
 filters=subprocess.check_output([shutil.which('ffmpeg'),'-hide_banner','-filters'],text=True,stderr=subprocess.STDOUT)
 for required in ('silencedetect','vfrdet','atrim','trim','apad'):
  if required not in filters:raise SystemExit('FFmpeg is missing filter: '+required)
 encoders=subprocess.check_output([shutil.which('ffmpeg'),'-hide_banner','-encoders'],text=True,stderr=subprocess.STDOUT)
 if 'libx264' not in encoders:raise SystemExit('FFmpeg needs libx264 for the optional MP4 review render.')
 (ROOT/'dependency-audit.json').write_text(json.dumps(audit,indent=2),encoding='utf-8')
 print('Setup complete. Next: Download-Model.cmd, then Start-Backend.cmd. See docs/WINDOWS.md to load the panel.')
if __name__=='__main__':
 try:main()
 except subprocess.CalledProcessError as e:raise SystemExit(f'Setup failed (exit {e.returncode}). Read the error above; no security setting was changed.')
